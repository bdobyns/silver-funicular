# Copyright 2001-2004 The Apache Software Foundation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
package APR::Const;

use ModPerl::Const ();
use APR ();
use XSLoader ();

our $VERSION = '0.01';
our @ISA = qw(ModPerl::Const);

XSLoader::load(__PACKAGE__, $VERSION);

1;

=head1 NAME

APR::Const - Perl Interface for APR Constants






=head1 Synopsis

  # make the constants available but don't import them
  use APR::Const -compile => qw(constant names ...);
  
  # w/o the => syntax sugar
  use APR::Const ("-compile", qw(constant names ...));
  
  # compile and import the constants
  use APR::Const qw(constant names ...);







=head1 Description

This package contains constants specific to C<APR> features.

Refer to C<L<the Apache::Const description
section|docs::2.0::api::Apache::Const/Description>> for more
information.







=head1 Constants



=head2 C<:common>

  use APR::Const -compile => qw(:common);

The C<:common> group is for XXX constants.




=head3 C<APR::SUCCESS>

=over

=item since: 1.99_12

=back





=head2 C<:error>

  use APR::Const -compile => qw(:error);

The C<:error> group is for XXX constants.




=head3 C<APR::EABOVEROOT>

=over

=item since: 1.99_12

=back





=head3 C<APR::EABSOLUTE>

=over

=item since: 1.99_12

=back





=head3 C<APR::EACCES>

=over

=item since: 1.99_12

=back





=head3 C<APR::EAGAIN>

=over

=item since: 1.99_12

=back

The error I<Resource temporarily unavailable>, may be returned by many
different system calls, especially IO calls.



=head3 C<APR::EBADDATE>

=over

=item since: 1.99_12

=back





=head3 C<APR::EBADF>

=over

=item since: 1.99_12

=back





=head3 C<APR::EBADIP>

=over

=item since: 1.99_12

=back





=head3 C<APR::EBADMASK>

=over

=item since: 1.99_12

=back





=head3 C<APR::EBADPATH>

=over

=item since: 1.99_12

=back





=head3 C<APR::EBUSY>

=over

=item since: 1.99_12

=back





=head3 C<APR::ECONNABORTED>

=over

=item since: 1.99_12

=back





=head3 C<APR::ECONNREFUSED>

=over

=item since: 1.99_12

=back





=head3 C<APR::ECONNRESET>

=over

=item since: 1.99_12

=back





=head3 C<APR::EDSOOPEN>

=over

=item since: 1.99_12

=back





=head3 C<APR::EEXIST>

=over

=item since: 1.99_12

=back





=head3 C<APR::EFTYPE>

=over

=item since: 1.99_12

=back





=head3 C<APR::EGENERAL>

=over

=item since: 1.99_12

=back





=head3 C<APR::EHOSTUNREACH>

=over

=item since: 1.99_12

=back





=head3 C<APR::EINCOMPLETE>

=over

=item since: 1.99_12

=back





=head3 C<APR::EINIT>

=over

=item since: 1.99_12

=back





=head3 C<APR::EINPROGRESS>

=over

=item since: 1.99_12

=back





=head3 C<APR::EINTR>

=over

=item since: 1.99_12

=back





=head3 C<APR::EINVAL>

=over

=item since: 1.99_12

=back





=head3 C<APR::EINVALSOCK>

=over

=item since: 1.99_12

=back





=head3 C<APR::EMFILE>

=over

=item since: 1.99_12

=back





=head3 C<APR::EMISMATCH>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENAMETOOLONG>

=over

=item since: 1.99_12

=back





=head3 C<APR::END>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENETUNREACH>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENFILE>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENODIR>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOENT>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOLOCK>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOMEM>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOPOLL>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOPOOL>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOPROC>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOSHMAVAIL>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOSOCKET>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOSPC>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOSTAT>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOTDIR>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOTEMPTY>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOTHDKEY>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOTHREAD>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOTIME>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOTIMPL>

=over

=item since: 1.99_12

=back





=head3 C<APR::ENOTSOCK>

=over

=item since: 1.99_12

=back





=head3 C<APR::EOF>

=over

=item since: 1.99_12

=back





=head3 C<APR::EPATHWILD>

=over

=item since: 1.99_12

=back





=head3 C<APR::EPIPE>

=over

=item since: 1.99_12

=back





=head3 C<APR::EPROC_UNKNOWN>

=over

=item since: 1.99_12

=back





=head3 C<APR::ERELATIVE>

=over

=item since: 1.99_12

=back





=head3 C<APR::ESPIPE>

=over

=item since: 1.99_12

=back





=head3 C<APR::ESYMNOTFOUND>

=over

=item since: 1.99_12

=back





=head3 C<APR::ETIMEDOUT>

=over

=item since: 1.99_12

=back





=head3 C<APR::EXDEV>

=over

=item since: 1.99_12

=back





=head2 C<:filemode>

  use APR::Const -compile => qw(:filemode);

The C<:filemode> group is for XXX constants.




=head3 C<APR::BINARY>

=over

=item since: 1.99_12

=back





=head3 C<APR::BUFFERED>

=over

=item since: 1.99_12

=back





=head3 C<APR::CREATE>

=over

=item since: 1.99_12

=back





=head3 C<APR::DELONCLOSE>

=over

=item since: 1.99_12

=back





=head3 C<APR::EXCL>

=over

=item since: 1.99_12

=back





=head3 C<APR::PEND>

=over

=item since: 1.99_12

=back





=head3 C<APR::READ>

=over

=item since: 1.99_12

=back





=head3 C<APR::TRUNCATE>

=over

=item since: 1.99_12

=back





=head3 C<APR::WRITE>

=over

=item since: 1.99_12

=back





=head2 C<:filepath>

  use APR::Const -compile => qw(:filepath);

The C<:filepath> group is for XXX constants.





=head3 C<APR::FILEPATH_ENCODING_LOCALE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_ENCODING_UNKNOWN>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_ENCODING_UTF8>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_NATIVE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_NOTABOVEROOT>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_NOTABSOLUTE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_NOTRELATIVE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_SECUREROOT>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_SECUREROOTTEST>

=over

=item since: 1.99_12

=back





=head3 C<APR::FILEPATH_TRUENAME>

=over

=item since: 1.99_12

=back





=head2 C<:fileperms>

  use APR::Const -compile => qw(:fileperms);

The C<:fileperms> group is for XXX constants.




=head3 C<APR::GEXECUTE>

=over

=item since: 1.99_12

=back





=head3 C<APR::GREAD>

=over

=item since: 1.99_12

=back





=head3 C<APR::GWRITE>

=over

=item since: 1.99_12

=back





=head3 C<APR::UEXECUTE>

=over

=item since: 1.99_12

=back





=head3 C<APR::UREAD>

=over

=item since: 1.99_12

=back





=head3 C<APR::UWRITE>

=over

=item since: 1.99_12

=back





=head3 C<APR::WEXECUTE>

=over

=item since: 1.99_12

=back





=head3 C<APR::WREAD>

=over

=item since: 1.99_12

=back





=head3 C<APR::WWRITE>

=over

=item since: 1.99_12

=back





=head2 C<:filetype>

  use APR::Const -compile => qw(:filetype);

The C<:filetype> group is for XXX constants.




=head3 C<APR::NOFILE>

=over

=item since: 1.99_12

=back





=head3 C<APR::REG>

=over

=item since: 1.99_12

=back





=head3 C<APR::DIR>

=over

=item since: 1.99_12

=back





=head3 C<APR::CHR>

=over

=item since: 1.99_12

=back





=head3 C<APR::BLK>

=over

=item since: 1.99_12

=back





=head3 C<APR::PIPE>

=over

=item since: 1.99_12

=back





=head3 C<APR::LNK>

=over

=item since: 1.99_12

=back





=head3 C<APR::SOCK>

=over

=item since: 1.99_12

=back





=head3 C<APR::UNKFILE>

=over

=item since: 1.99_12

=back





=head2 C<:finfo>

  use APR::Const -compile => qw(:finfo);

The C<:finfo> group is for XXX constants.




=head3 C<APR::FINFO_ATIME>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_CSIZE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_CTIME>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_DEV>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_DIRENT>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_GPROT>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_GROUP>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_ICASE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_IDENT>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_INODE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_LINK>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_MIN>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_MTIME>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_NAME>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_NLINK>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_NORM>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_OWNER>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_PROT>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_SIZE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_TYPE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_UPROT>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_USER>

=over

=item since: 1.99_12

=back





=head3 C<APR::FINFO_WPROT>

=over

=item since: 1.99_12

=back





=head2 C<:flock>

  use APR::Const -compile => qw(:flock);

The C<:flock> group is for XXX constants.




=head3 C<APR::FLOCK_EXCLUSIVE>

=over

=item since: 1.99_12

=back





=head3 C<APR::FLOCK_NONBLOCK>

=over

=item since: 1.99_12

=back





=head3 C<APR::FLOCK_SHARED>

=over

=item since: 1.99_12

=back





=head3 C<APR::FLOCK_TYPEMASK>

=over

=item since: 1.99_12

=back





=head2 C<:hook>

  use APR::Const -compile => qw(:hook);

The C<:hook> group is for XXX constants.




=head3 C<APR::HOOK_FIRST>

=over

=item since: 1.99_12

=back





=head3 C<APR::HOOK_LAST>

=over

=item since: 1.99_12

=back





=head3 C<APR::HOOK_MIDDLE>

=over

=item since: 1.99_12

=back





=head3 C<APR::HOOK_REALLY_FIRST>

=over

=item since: 1.99_12

=back





=head3 C<APR::HOOK_REALLY_LAST>

=over

=item since: 1.99_12

=back





=head2 C<:limit>

  use APR::Const -compile => qw(:limit);

The C<:limit> group is for XXX constants.




=head3 C<APR::LIMIT_CPU>

=over

=item since: 1.99_12

=back





=head3 C<APR::LIMIT_MEM>

=over

=item since: 1.99_12

=back





=head3 C<APR::LIMIT_NOFILE>

=over

=item since: 1.99_12

=back





=head3 C<APR::LIMIT_NPROC>

=over

=item since: 1.99_12

=back





=head2 C<:lockmech>

  use APR::Const -compile => qw(:lockmech);

The C<:lockmech> group is for XXX constants.




=head3 C<APR::LOCK_DEFAULT>

=over

=item since: 1.99_12

=back





=head3 C<APR::LOCK_FCNTL>

=over

=item since: 1.99_12

=back





=head3 C<APR::LOCK_FLOCK>

=over

=item since: 1.99_12

=back





=head3 C<APR::LOCK_POSIXSEM>

=over

=item since: 1.99_12

=back





=head3 C<APR::LOCK_PROC_PTHREAD>

=over

=item since: 1.99_12

=back





=head3 C<APR::LOCK_SYSVSEM>

=over

=item since: 1.99_12

=back





=head2 C<:poll>

  use APR::Const -compile => qw(:poll);

The C<:poll> group is for XXX constants.




=head3 C<APR::POLLERR>

=over

=item since: 1.99_12

=back





=head3 C<APR::POLLHUP>

=over

=item since: 1.99_12

=back





=head3 C<APR::POLLIN>

=over

=item since: 1.99_12

=back





=head3 C<APR::POLLNVAL>

=over

=item since: 1.99_12

=back





=head3 C<APR::POLLOUT>

=over

=item since: 1.99_12

=back





=head3 C<APR::POLLPRI>

=over

=item since: 1.99_12

=back





=head2 C<:read_type>

  use APR::Const -compile => qw(:read_type);

The C<:read_type> group is for IO constants.




=head3 C<APR::BLOCK_READ>

=over

=item since: 1.99_12

=back

the read function blocks





=head3 C<APR::NONBLOCK_READ>

=over

=item since: 1.99_12

=back


the read function does not block










=head2 C<:shutdown_how>

  use APR::Const -compile => qw(:shutdown_how);

The C<:shutdown_how> group is for XXX constants.




=head3 C<APR::SHUTDOWN_READ>

=over

=item since: 1.99_12

=back





=head3 C<APR::SHUTDOWN_READWRITE>

=over

=item since: 1.99_12

=back





=head3 C<APR::SHUTDOWN_WRITE>

=over

=item since: 1.99_12

=back





=head2 C<:socket>

  use APR::Const -compile => qw(:socket);

The C<:socket> group is for the
C<L<APR::Socket|docs::2.0::api::APR::Socket>> object constants, in
methods C<L<opt_get|docs::2.0::api::APR::Socket/C_opt_get_>> and
C<L<opt_set|docs::2.0::api::APR::Socket/C_opt_set_>>.

The following section discusses in detail each of the C<:socket>
constants.




=head3 C<APR::SO_DEBUG>

Possible values:

XXX

=over

=item since: 1.99_12

=back

Turns on debugging information




=head3 C<APR::SO_DISCONNECTED>

Queries the disconnected state of the socket.  (Currently only used on
Windows)

Possible values:

XXX

=over

=item since: 1.99_12

=back






=head3 C<APR::SO_KEEPALIVE>

Keeps connections active

Possible values:

XXX

=over

=item since: 1.99_12

=back








=head3 C<APR::SO_LINGER>

Lingers on close if data is present

=over

=item since: 1.99_12

=back







=head3 C<APR::SO_NONBLOCK>

Turns blocking IO mode on/off for socket.

Possible values:

  1 nonblocking
  0 blocking

For example, to set a socket to a blocking IO mode:

  use APR::Socket ();
  use APR::Const    -compile => qw(SO_NONBLOCK);
  ...
  if ($socket->opt_get(APR::SO_NONBLOCK)) {
      $socket->opt_set(APR::SO_NONBLOCK => 0);
  }

You don't have to query for this option, before setting it. It was
done for the demonstration purpose.

=over

=item since: 1.99_12

=back









=head3 C<APR::SO_RCVBUF>

Controls the C<ReceiveBufferSize> setting

Possible values:

XXX

=over

=item since: 1.99_12

=back








=head3 C<APR::SO_REUSEADDR>

The rules used in validating addresses supplied to bind should allow
reuse of local addresses.

Possible values:

XXX

=over

=item since: 1.99_12

=back








=head3 C<APR::SO_SNDBUF>

Controls the C<SendBufferSize> setting

Possible values:

XXX

=over

=item since: 1.99_12

=back





=head2 C<:status>

  use APR::Const -compile => qw(:status);

The C<:status> group is for the API that return status code, or set
the error variable XXXXXX.

The following section discusses in detail each of the available
C<:status> constants.




=head3 C<APR::TIMEUP>

The operation did not finish before the timeout.

=over

=item since: 1.99_14

=back














=head2 C<:table>

  use APR::Const -compile => qw(:table);

The C<:table> group is for C<overlap()> and C<compress()> constants.
See C<L<APR::Table|docs::2.0::api::APR::Table>> for details.




=head3 C<APR::OVERLAP_TABLES_MERGE>

=over

=item since: 1.99_12

=back

See C<L<APR::Table::compress|docs::2.0::api::APR::Table/C_compress_>>
and C<L<APR::Table::overlap|docs::2.0::api::APR::Table/C_overlap_>>.





=head3 C<APR::OVERLAP_TABLES_SET>

=over

=item since: 1.99_12

=back

See C<L<APR::Table::compress|docs::2.0::api::APR::Table/C_compress_>>
and C<L<APR::Table::overlap|docs::2.0::api::APR::Table/C_overlap_>>.





=head2 C<:uri>

  use APR::Const -compile => qw(:uri);

The C<:uri> group of constants is for manipulating URIs.




=head3 C<APR::URI_ACAP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back





=head3 C<APR::URI_FTP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back





=head3 C<APR::URI_GOPHER_DEFAULT_PORT>

=over

=item since: 1.99_12

=back





=head3 C<APR::URI_HTTPS_DEFAULT_PORT>

=over

=item since: 1.99_12

=back






=head3 C<APR::URI_HTTP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back






=head3 C<APR::URI_IMAP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back





=head3 C<APR::URI_LDAP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back






=head3 C<APR::URI_NFS_DEFAULT_PORT>

=over

=item since: 1.99_12

=back






=head3 C<APR::URI_NNTP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back






=head3 C<APR::URI_POP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back






=head3 C<APR::URI_PROSPERO_DEFAULT_PORT>

=over

=item since: 1.99_12

=back






=head3 C<APR::URI_RTSP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back







=head3 C<APR::URI_SIP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back









=head3 C<APR::URI_SNEWS_DEFAULT_PORT>

=over

=item since: 1.99_12

=back





=head3 C<APR::URI_SSH_DEFAULT_PORT>

=over

=item since: 1.99_12

=back





=head3 C<APR::URI_TELNET_DEFAULT_PORT>

=over

=item since: 1.99_12

=back







=head3 C<APR::URI_TIP_DEFAULT_PORT>

=over

=item since: 1.99_12

=back








=head3 C<APR::URI_UNP_OMITPASSWORD>

=over

=item since: 1.99_12

=back

See C<L<APR::URI::unparse|docs::2.0::api::APR::URI/C_unparse_>>.








=head3 C<APR::URI_UNP_OMITPATHINFO>

=over

=item since: 1.99_12

=back

See C<L<APR::URI::unparse|docs::2.0::api::APR::URI/C_unparse_>>.








=head3 C<APR::URI_UNP_OMITQUERY>

=over

=item since: 1.99_12

=back

See C<L<APR::URI::unparse|docs::2.0::api::APR::URI/C_unparse_>>.








=head3 C<APR::URI_UNP_OMITSITEPART>

=over

=item since: 1.99_12

=back

See C<L<APR::URI::unparse|docs::2.0::api::APR::URI/C_unparse_>>.







=head3 C<APR::URI_UNP_OMITUSER>

=over

=item since: 1.99_12

=back

See C<L<APR::URI::unparse|docs::2.0::api::APR::URI/C_unparse_>>.





=head3 C<APR::URI_UNP_OMITUSERINFO>

=over

=item since: 1.99_12

=back








=head3 C<APR::URI_UNP_REVEALPASSWORD>

=over

=item since: 1.99_12

=back

See C<L<APR::URI::unparse|docs::2.0::api::APR::URI/C_unparse_>>.







=head3 C<APR::URI_WAIS_DEFAULT_PORT>

=over

=item since: 1.99_12

=back



=head2 Other Constants


=head3 C<APR::PerlIO::PERLIO_LAYERS_ARE_ENABLED>

=over

=item since: 1.99_10

=back

See C<L<APR::PerlIO::Constants|docs::2.0::api::APR::PerlIO/Constants>>)





=head1 See Also

L<mod_perl 2.0 documentation|docs::2.0::index>.




=head1 Copyright

mod_perl 2.0 and its core modules are copyrighted under
The Apache Software License, Version 2.0.




=head1 Authors

L<The mod_perl development team and numerous
contributors|about::contributors::people>.

=cut
